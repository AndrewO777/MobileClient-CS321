package com.example.school_mobileapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

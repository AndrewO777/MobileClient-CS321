// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format width=80

part of 'api_service.dart';

// **************************************************************************
// ChopperGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
final class _$ApiService extends ApiService {
  _$ApiService([ChopperClient? client]) {
    if (client == null) return;
    this.client = client;
  }

  @override
  final Type definitionType = ApiService;

  @override
  Future<Response<List<Map<String, dynamic>>>> getSchools() {
    final Uri $url = Uri.parse('School');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<List<Map<String, dynamic>>, Map<String, dynamic>>(
      $request,
    );
  }

  @override
  Future<Response<Map<String, dynamic>>> getSchool(int id) {
    final Uri $url = Uri.parse('School/${id}');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<Map<String, dynamic>, Map<String, dynamic>>($request);
  }

  @override
  Future<Response<List<Map<String, dynamic>>>> getAnnouncements() {
    final Uri $url = Uri.parse('Announcement');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<List<Map<String, dynamic>>, Map<String, dynamic>>(
      $request,
    );
  }

  @override
  Future<Response<Map<String, dynamic>>> getAnnouncement(int id) {
    final Uri $url = Uri.parse('Announcement/${id}');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<Map<String, dynamic>, Map<String, dynamic>>($request);
  }

  @override
  Future<Response<List<Map<String, dynamic>>>> getNews() {
    final Uri $url = Uri.parse('News');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<List<Map<String, dynamic>>, Map<String, dynamic>>(
      $request,
    );
  }

  @override
  Future<Response<Map<String, dynamic>>> getNewsItem(int id) {
    final Uri $url = Uri.parse('News/${id}');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<Map<String, dynamic>, Map<String, dynamic>>($request);
  }

  @override
  Future<Response<List<Map<String, dynamic>>>> getEvents() {
    final Uri $url = Uri.parse('Events');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<List<Map<String, dynamic>>, Map<String, dynamic>>(
      $request,
    );
  }

  @override
  Future<Response<Map<String, dynamic>>> getEvent(int id) {
    final Uri $url = Uri.parse('Events/${id}');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<Map<String, dynamic>, Map<String, dynamic>>($request);
  }

  @override
  Future<Response<List<Map<String, dynamic>>>> getCafeteriaMenus() {
    final Uri $url = Uri.parse('Cafeteria');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<List<Map<String, dynamic>>, Map<String, dynamic>>(
      $request,
    );
  }

  @override
  Future<Response<Map<String, dynamic>>> getCafeteriaMenu(int id) {
    final Uri $url = Uri.parse('Cafeteria/${id}');
    final Request $request = Request('GET', $url, client.baseUrl);
    return client.send<Map<String, dynamic>, Map<String, dynamic>>($request);
  }
}
